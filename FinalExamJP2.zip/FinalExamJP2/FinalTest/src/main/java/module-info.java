module org.example.finaltest {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    opens org.example.finaltest to javafx.fxml;
    exports org.example.finaltest;
    exports org.example.finaltest.controller;
    opens org.example.finaltest.controller to javafx.fxml;
}