package org.example.finaltest.repository;

import org.example.finaltest.entity.National;
import org.example.finaltest.entity.Player;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PlayerRepository implements IPlayerRepository{
    @Override
    public void addPlayer(Player player) {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call ADD_PLAYER(?, ?, ?, ?)}");
            statement.setInt("national_id", player.getNationalId());
            statement.setString("player_name", player.getPlayerName());
            statement.setInt("high_score", player.getHighScore());
            statement.setInt("level", player.getLevel());
            statement.execute();
            statement.close();
        } catch (SQLException e) {
            System.out.println(e);
        }

    }

    @Override
    public void addNational(National national) {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call ADD_NATIONAL(?)}");
            statement.setString("national_name", national.getNationalName());
            statement.execute();
            statement.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Player> getAllPlayers() {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call GET_ALL_PLAYERS}");
            boolean hasResult = statement.execute();
            if (hasResult) {
                ResultSet result = statement.getResultSet();
                List<Player> playerList = new ArrayList<>();
                while (result.next()) {
                    int playerId = result.getInt("PlayerId");
                    int nationalId = result.getInt("NationalId");
                    String playerName = result.getString("PlayerName");
                    int highScore = result.getInt("HighScore");
                    int level = result.getInt("Level");
                    Player player = new Player(nationalId, playerName, highScore, level);
                    player.setPlayerId(playerId);
                    playerList.add(player);
                }
                return playerList;
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    @Override
    public List<Player> getTopHighScore() {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call GET_TOP_HIGH_SCORE}");
            boolean hasResult = statement.execute();
            if (hasResult) {
                ResultSet result = statement.getResultSet();
                List<Player> playerList = new ArrayList<>();
                while (result.next()) {
                    int playerId = result.getInt("PlayerId");
                    int nationalId = result.getInt("NationalId");
                    String playerName = result.getString("PlayerName");
                    int highScore = result.getInt("HighScore");
                    int level = result.getInt("Level");
                    Player player = new Player(nationalId, playerName, highScore, level);
                    player.setPlayerId(playerId);
                    playerList.add(player);
                }
                return playerList;
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    @Override
    public Player findByName(String findPlayerName) {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call FIND_PLAYER_BY_NAME(?)}");
            statement.setString("player_name", findPlayerName);
            boolean hasResult = statement.execute();
            if (hasResult) {
                ResultSet result = statement.getResultSet();
                if (result.next()) {
                    int playerId = result.getInt("PlayerId");
                    int nationalId = result.getInt("NationalId");
                    String playerName = result.getString("PlayerName");
                    int highScore = result.getInt("HighScore");
                    int level = result.getInt("Level");
                    Player player = new Player(nationalId, playerName, highScore, level);
                    player.setPlayerId(playerId);
                    return player;
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    @Override
    public void deletePlayer(int playerId) {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call DELETE_PLAYER(?)}");
            statement.setInt("player_id", playerId);
            statement.execute();
            statement.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public void deleteNational(int nationalId) {
        try {
            var conn = ConnectJDBC.getInstance().getConnection();
            CallableStatement statement = conn.prepareCall("{call DELETE_NATIONAL(?)}");
            statement.setInt("national_id", nationalId);
            statement.execute();
            statement.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
