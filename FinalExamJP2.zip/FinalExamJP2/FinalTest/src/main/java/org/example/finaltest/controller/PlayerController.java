package org.example.finaltest.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.finaltest.entity.National;
import org.example.finaltest.entity.Player;
import org.example.finaltest.repository.PlayerRepository;

import java.util.List;

public class PlayerController {

    @FXML
    private TextField txtPlayerName, txtNationalId, txtHighScore, txtLevel, txtFindName, txtDeletePlayer, txtDeleteNational, txtNationalName;
    @FXML
    private Button btnAddPlayer, btnFindName, btnDeletePlayer, btnDeleteNational, btnShowAll, btnShowTop;
    @FXML
    private Label lblMessage;
    @FXML
    private TableView tableView;

    @FXML
    private void insertPlayer (Player player) {
        try {
            PlayerRepository playerRepository = new PlayerRepository();
            playerRepository.addPlayer(player);
            lblMessage.setText("Added player: " + player.getPlayerName() + ", national ID: " + player.getNationalId() +
                    ", highscore: " + player.getHighScore() + ", level: " + player.getLevel());
        } catch (Exception e) {
            lblMessage.setText(e.getMessage());
        }
    }

    @FXML
    private void onAddPlayer() {
        Player player = new Player(Integer.parseInt(txtNationalId.getText()), txtPlayerName.getText(),
                Integer.parseInt(txtHighScore.getText()), Integer.parseInt(txtLevel.getText()));
        insertPlayer(player);
    }

    @FXML
    private void insertNational (National national) {
        try {
            PlayerRepository playerRepository = new PlayerRepository();
            playerRepository.addNational(national);
            lblMessage.setText("Added national " + national.getNationalName());
        } catch (Exception e) {
            lblMessage.setText(e.getMessage());
        }
    }

    @FXML
    private void onAddNational() {
        National national = new National(txtNationalName.getText());
        insertNational(national);
    }

    @FXML
    private void findPlayer(String playerName) {
        try {
            PlayerRepository playerRepository = new PlayerRepository();
            Player player = playerRepository.findByName(playerName);
            if (player != null) {
                lblMessage.setText("Player found\nPlayer ID: " + player.getPlayerId() + ", name: " + playerName +
                        ", highscore: " + player.getHighScore() + " level: " + player.getLevel());
            } else {
                lblMessage.setText("No players found.");
            }
        } catch (Exception e) {
            lblMessage.setText(e.getMessage());
        }

    }

    @FXML
    private void onFindByName() {
        findPlayer(txtFindName.getText());
    }

    @FXML
    private void onDeletePlayer() {
        try {
            PlayerRepository playerRepository = new PlayerRepository();
            playerRepository.deletePlayer(Integer.parseInt(txtDeletePlayer.getText()));
        } catch (Exception e) {
            lblMessage.setText(e.getMessage());
        }
    }

    @FXML
    private void onDeleteNational() {
        try {
            PlayerRepository playerRepository = new PlayerRepository();
            playerRepository.deleteNational(Integer.parseInt(txtDeleteNational.getText()));
        } catch (Exception e) {
            lblMessage.setText(e.getMessage());
        }
    }

    @FXML
    private void onShowAll() {
        initPlayer();
    }

    public void initPlayer() {
        PlayerRepository playerRepository = new PlayerRepository();
        List<Player> players = playerRepository.getAllPlayers();
        TableColumn<Player, Integer> playerId = new TableColumn<>("Player ID");
        playerId.setCellValueFactory(new PropertyValueFactory<>("playerId"));

        TableColumn<Player, String> playerName = new TableColumn<>("Player Name");
        playerName.setCellValueFactory(new PropertyValueFactory<>("playerName"));

        TableColumn<Player, Integer> highScore = new TableColumn<>("High Score");
        highScore.setCellValueFactory(new PropertyValueFactory<>("highScore"));

        TableColumn<Player, Integer> level = new TableColumn<>("Level");
        level.setCellValueFactory(new PropertyValueFactory<>("level"));

        TableColumn<National, String> national = new TableColumn<>("National");
        national.setCellValueFactory(new PropertyValueFactory<>("nationalName"));

        ObservableList<Player> dataPlayers = FXCollections.observableArrayList(players);


        tableView.getColumns().addAll(playerId, playerName, highScore, level, national);

        tableView.setItems(dataPlayers);
    }

}