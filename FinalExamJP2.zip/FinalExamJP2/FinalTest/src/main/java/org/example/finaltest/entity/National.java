package org.example.finaltest.entity;

public class National {
    private String nationalName;

    public National(String nationalName) {
        this.nationalName = nationalName;
    }

    public String getNationalName() {
        return nationalName;
    }

    public void setNationalName(String nationalName) {
        this.nationalName = nationalName;
    }
}
