package org.example.finaltest.repository;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class ConnectJDBC {
    private static Connection connection;
    private final String local = "localhost";
    private final Integer port = 3300;
    private final String database = "herogame";
    private final String username = "root";
    private final String password = "phong.ndh20091808";
    private final String host = local + ":" + port;
    private final String url = "jdbc:mysql://" + host + "/" + database;

    private static ConnectJDBC connectJDBC;
    public static ConnectJDBC getInstance() {
        if (connectJDBC == null) {
            synchronized (ConnectJDBC.class) {
                connectJDBC = new ConnectJDBC();
                return connectJDBC;
            }
        }
        return connectJDBC;
    }

    public ConnectJDBC() {
        try {
            connection = DriverManager.getConnection(url, username, password);
            if (connection != null && !connection.isClosed()) {
                System.out.println("Connected to database");
            } else {
                System.out.println("Failed to connect to database");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Connection getConnection() {
        return connection;
    }
}
