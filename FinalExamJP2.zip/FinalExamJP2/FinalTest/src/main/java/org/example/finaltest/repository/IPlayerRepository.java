package org.example.finaltest.repository;

import org.example.finaltest.entity.National;
import org.example.finaltest.entity.Player;

import java.util.List;

public interface IPlayerRepository {
    void addPlayer(Player player);
    void addNational(National national);
    List<Player> getAllPlayers();
    List<Player> getTopHighScore();
    Player findByName(String playerName);
    void deletePlayer(int playerId);
    void deleteNational(int nationalId);
}
